package lk.ijse.dto;

public class BorrowBookDto {
}
