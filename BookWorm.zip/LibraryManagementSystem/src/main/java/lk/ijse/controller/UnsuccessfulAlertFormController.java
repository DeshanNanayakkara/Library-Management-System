package lk.ijse.controller;

import javafx.scene.control.Label;

public class UnsuccessfulAlertFormController {
    public Label txtMessage;
}
