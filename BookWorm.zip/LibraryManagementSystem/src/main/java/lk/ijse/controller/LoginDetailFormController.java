package lk.ijse.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class LoginDetailFormController {
    public TextField txtUsername;
    public TextField txtPassword;

    public void btnloginonAction(ActionEvent actionEvent) {
    }
}
