package lk.ijse.service;

public interface SuperService {
}
