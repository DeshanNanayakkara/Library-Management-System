package lk.ijse.util;

public class ValidateUtil {
}
